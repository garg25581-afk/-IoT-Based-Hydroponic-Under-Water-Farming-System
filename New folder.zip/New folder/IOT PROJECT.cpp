#define BLYNK_TEMPLATE_ID "TMPL3v9-ivhb_"
#define BLYNK_TEMPLATE_NAME "iot"
#define BLYNK_AUTH_TOKEN "ThxsVBOwGvmuOrgUCiKnx9c6NaHboD-q"


#define BLYNK_PRINT Serial

#include <WiFi.h>
#include <WiFiClient.h>
#include <BlynkSimpleEsp32.h>
#include <DHT.h>
#include <LiquidCrystal_I2C.h>

// Blynk Auth Token
char auth[] = "ThxsVBOwGvmuOrgUCiKnx9c6NaHboD-q";

// Your WiFi credentials
char ssid[] = "Ankit";
char pass[] = "ankit123";

// DHT setup
#define DHTPIN 4
#define DHTTYPE DHT11
DHT dht(DHTPIN, DHTTYPE);

// Soil sensor (Using 34, which is an Input-Only pin on ESP32 - perfect for Analog)
#define SOIL_PIN 34

// LCD setup (Address 0x27 is common, but 0x3F is sometimes used)
LiquidCrystal_I2C lcd(0x27, 16, 2);

// Timer
BlynkTimer timer;

void sendData()
{
  float temp = dht.readTemperature();
  float hum = dht.readHumidity();
  int soilRaw = analogRead(SOIL_PIN);

  // Check if any reads failed and exit early (to avoid sending garbage data)
  if (isnan(hum) || isnan(temp)) {
    Serial.println("Failed to read from DHT sensor!");
    return;
  }

  // Convert to percentage (ESP32 ADC is 12-bit: 0-4095)
  // Note: If 100% shows when dry, swap 4095 and 0 in the map function
  int moisture = map(soilRaw, 4095, 0, 0, 100);
  moisture = constrain(moisture, 0, 100); // Keep it within 0-100%

  String crop;
  if (moisture <= 30)
    crop = "Millet";
  else if (moisture <= 50)
    crop = "Okra";
  else
    crop = "Rice";

  // LCD display
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("M:"); lcd.print(moisture); lcd.print("% ");
  lcd.print("T:"); lcd.print((int)temp); lcd.print("C");

  lcd.setCursor(0, 1);
  lcd.print("Crop: ");
  lcd.print(crop);

  // Send to Blynk Virtual Pins
  Blynk.virtualWrite(V0, temp);
  Blynk.virtualWrite(V1, hum);
  Blynk.virtualWrite(V2, moisture);
  Blynk.virtualWrite(V3, crop);

  // Serial Monitor for debugging
  Serial.print("Moisture: "); Serial.print(moisture); Serial.println("%");
  Serial.print("Recommended Crop: "); Serial.println(crop);
  Serial.println("-----------------------");
}

void setup()
{
  Serial.begin(115200);

  dht.begin();
  
  // Initialize LCD
  lcd.init();
  lcd.backlight();
  lcd.setCursor(0, 0);
  lcd.print("Crop Monitor");
  lcd.setCursor(0, 1);
  lcd.print("Connecting...");

  // Start Blynk
  Blynk.begin(auth, ssid, pass);
  
  // Setup a function to be called every 2 seconds
  timer.setInterval(2000L, sendData);
  
  lcd.clear();
}

void loop()
{
  Blynk.run();
  timer.run();
}